// import React, { useEffect, useState } from "react";
// import AdminNavbar from "../../Admin_Panel/Admin_Navbar/Admin_Navbar";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { baseurl } from "../../BaseURL/BaseURL";
// import "./ChatBot.css";

// function Chatbot() {
//   const navigate = useNavigate();
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   // Pagination states
//   const [page, setPage] = useState(1);
//   const itemsPerPage = 5;

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const res = await axios.get(`${baseurl}/responses/`);
//         setData(res.data.results || []);
//       } catch (err) {
//         console.error("Error fetching data:", err);
//         setError("Failed to load data");
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchData();
//   }, []);

//   const handleCreate = () => {
//     navigate("/admin-createq&a");
//   };

//   // Pagination logic
//   const startIndex = (page - 1) * itemsPerPage;
//   const paginatedData = data.slice(startIndex, startIndex + itemsPerPage);
//   const totalPages = Math.ceil(data.length / itemsPerPage);

//   const handleDelete = async (id) => {
//     if (window.confirm("Are you sure you want to delete this Q&A?")) {
//       try {
//         await axios.delete(`${baseurl}/responses/${id}/`);
//         setData(data.filter((item) => item.id !== id));
//       } catch (err) {
//         console.error("Error deleting Q&A:", err);
//         alert("Failed to delete Q&A");
//       }
//     }
//   };

//   return (
//     <>
//       <AdminNavbar />
//       <div className="chatbot-container">
//         {/* Header */}
//         <div className="chatbot-header">
//           <h2 className="chatbot-title">Chatbot Q&A Table</h2>
//           <button
//             className="btn btn-primary create-btn"
//             onClick={handleCreate}
//           >
//             Create Q&A
//           </button>
//         </div>

//         {/* Loader / Error */}
//         {loading ? (
//           <div className="text-center my-4">
//             <div className="spinner-border" role="status">
//               <span className="visually-hidden">Loading...</span>
//             </div>
//           </div>
//         ) : error ? (
//           <div className="alert alert-danger text-center" role="alert">
//             {error}
//           </div>
//         ) : (
//           <>
//             <div className="table-responsive">
//               <table className="table table-striped table-hover">
//                 <thead className="table-light">
//                   <tr>
//                     <th scope="col">Question</th>
//                     <th scope="col">Answer</th>
//                     <th scope="col">Actions</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {paginatedData.length > 0 ? (
//                     paginatedData.map((item, index) => (
//                       <tr key={index}>
//                         <td>{item.question}</td>
//                         <td>{item.answer}</td>
//                         <td>
//                           <button
//                             className="btn btn-sm btn-outline-primary me-2"
//                             onClick={() => navigate(`/admin-editqa/${item.id}`)}
//                           >
//                             <i className="bi bi-pencil"></i> Edit
//                           </button>
//                           <button
//                             className="btn btn-sm btn-outline-danger"
//                             onClick={() => handleDelete(item.id)}
//                           >
//                             <i className="bi bi-trash"></i> Delete
//                           </button>
//                         </td>
//                       </tr>
//                     ))
//                   ) : (
//                     <tr>
//                       <td colSpan="3" className="text-center">
//                         No data available
//                       </td>
//                     </tr>
//                   )}
//                 </tbody>
//               </table>
//             </div>

//             {/* Pagination */}
//             {!loading && data.length > 0 && (
//               <nav aria-label="Page navigation" className="mt-3">
//                 <ul className="pagination justify-content-end">
//                   <li className={`page-item ${page === 1 ? "disabled" : ""}`}>
//                     <button
//                       className="page-link"
//                       onClick={() => setPage(page - 1)}
//                     >
//                       Previous
//                     </button>
//                   </li>
//                   {[...Array(totalPages)].map((_, i) => (
//                     <li
//                       key={i}
//                       className={`page-item ${page === i + 1 ? "active" : ""}`}
//                     >
//                       <button
//                         className="page-link"
//                         onClick={() => setPage(i + 1)}
//                       >
//                         {i + 1}
//                       </button>
//                     </li>
//                   ))}
//                   <li className={`page-item ${page === totalPages ? "disabled" : ""}`}>
//                     <button
//                       className="page-link"
//                       onClick={() => setPage(page + 1)}
//                     >
//                       Next
//                     </button>
//                   </li>
//                 </ul>
//               </nav>
//             )}
//           </>
//         )}
//       </div>
//     </>
//   );
// }

// export default Chatbot;




// import React, { useEffect, useState } from "react";
// import AdminNavbar from "../../Admin_Panel/Admin_Navbar/Admin_Navbar";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { baseurl } from "../../BaseURL/BaseURL";
// import "./ChatBot.css";
// import Swal from "sweetalert2";

// function Chatbot() {
//   const navigate = useNavigate();
//   const [data, setData] = useState([]);
//   const [filteredData, setFilteredData] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [searchQuery, setSearchQuery] = useState("");
//   const [error, setError] = useState(null);

//   // Pagination states
//   const [page, setPage] = useState(1);
//   const itemsPerPage = 5;

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const res = await axios.get(`${baseurl}/responses/`);
//         const results = res.data.results || res.data || [];
//         setData(results);
//         setFilteredData(results);
//       } catch (err) {
//         console.error("Error fetching data:", err);
//         setError("Failed to load data");
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchData();
//   }, []);

//   /* ================= SEARCH ================= */
//   const safeToString = (v) => (v ? v.toString() : "");

//   useEffect(() => {
//     if (!searchQuery.trim()) {
//       setFilteredData(data);
//       return;
//     }

//     const q = searchQuery.toLowerCase();
//     const filtered = data.filter(
//       (item) =>
//         safeToString(item.question).toLowerCase().includes(q) ||
//         safeToString(item.answer).toLowerCase().includes(q) ||
//         safeToString(item.id).includes(q)
//     );

//     setFilteredData(filtered);
//   }, [searchQuery, data]);

//   const handleCreate = () => {
//     navigate("/admin-createq&a");
//   };

//   const handleEdit = (id) => {
//     navigate(`/admin-editqa/${id}`);
//   };

//   /* ================= DELETE ================= */
//   const handleDelete = (id) => {
//     Swal.fire({
//       title: "Are you sure?",
//       text: "This Q&A will be permanently deleted!",
//       icon: "warning",
//       showCancelButton: true,
//       confirmButtonColor: "#d33",
//       cancelButtonColor: "#6b7280",
//       confirmButtonText: "Yes, delete it!",
//       cancelButtonText: "Cancel",
//     }).then(async (result) => {
//       if (result.isConfirmed) {
//         try {
//           await axios.delete(`${baseurl}/responses/${id}/`);
//           const updatedData = data.filter((item) => item.id !== id);
//           setData(updatedData);
//           setFilteredData(updatedData);
//           Swal.fire("Deleted!", "Q&A has been deleted.", "success");
//         } catch (err) {
//           console.error("Error deleting Q&A:", err);
//           Swal.fire("Error!", "Failed to delete Q&A.", "error");
//         }
//       }
//     });
//   };

//   // Pagination logic
//   const startIndex = (page - 1) * itemsPerPage;
//   const paginatedData = filteredData.slice(startIndex, startIndex + itemsPerPage);
//   const totalPages = Math.ceil(filteredData.length / itemsPerPage);

//   return (
//     <>
//       <AdminNavbar />

//       <div className="page-container">
//         {/* Header */}
//         <div className="page-header">
//           <h2>Chatbot Q&A</h2>
//         </div>

//         {/* Toolbar */}
//         <div className="page-toolbar">
//           <div className="search-box">
//             <input
//               type="text"
//               placeholder="Search questions or answers..."
//               value={searchQuery}
//               onChange={(e) => setSearchQuery(e.target.value)}
//             />
//             <span className="search-icon">🔍</span>
//           </div>

//           <button
//             className="primary-btn"
//             style={{
//               backgroundColor: "#273c75",
//               borderColor: "#273c75",
//               color: "white",
//             }}
//             onClick={handleCreate}
//           >
//             Create Q&A
//           </button>
//         </div>

//         {/* Table */}
//         <div className="table-card">
//           <table className="data-table">
//             <thead>
//               <tr>
//                 <th>S.No.</th>
//                 <th>ID</th>
//                 <th>QUESTION</th>
//                 <th>ANSWER</th>
//                 <th>ACTIONS</th>
//               </tr>
//             </thead>

//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan="5" className="no-data">
//                     Loading...
//                   </td>
//                 </tr>
//               ) : error ? (
//                 <tr>
//                   <td colSpan="5" className="no-data error">
//                     {error}
//                   </td>
//                 </tr>
//               ) : paginatedData.length > 0 ? (
//                 paginatedData.map((item, index) => (
//                   <tr key={item.id}>
//                     <td>{startIndex + index + 1}</td>
//                     <td>{item.id}</td>
//                     <td className="question-cell">{item.question}</td>
//                     <td className="answer-cell">{item.answer}</td>
//                     <td className="actions">
//                       <button
//                         className="edit-btn"
//                         onClick={() => handleEdit(item.id)}
//                       >
//                         ✏️
//                       </button>
//                       <button
//                         className="delete-btn"
//                         onClick={() => handleDelete(item.id)}
//                       >
//                         🗑️
//                       </button>
//                     </td>
//                   </tr>
//                 ))
//               ) : (
//                 <tr>
//                   <td colSpan="5" className="no-data">
//                     No Q&A data found
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>

//           {/* Pagination */}
//           {!loading && !error && filteredData.length > 0 && totalPages > 1 && (
//             <div className="pagination-container">
//               <div className="pagination-info">
//                 Showing {startIndex + 1} to{" "}
//                 {Math.min(startIndex + itemsPerPage, filteredData.length)} of{" "}
//                 {filteredData.length} entries
//               </div>
//               <div className="pagination-controls">
//                 <button
//                   className="pagination-btn"
//                   onClick={() => setPage(page - 1)}
//                   disabled={page === 1}
//                 >
//                   ← Previous
//                 </button>
//                 <div className="page-numbers">
//                   {[...Array(totalPages)].map((_, i) => (
//                     <button
//                       key={i + 1}
//                       className={`page-number ${page === i + 1 ? "active" : ""}`}
//                       onClick={() => setPage(i + 1)}
//                     >
//                       {i + 1}
//                     </button>
//                   ))}
//                 </div>
//                 <button
//                   className="pagination-btn"
//                   onClick={() => setPage(page + 1)}
//                   disabled={page === totalPages}
//                 >
//                   Next →
//                 </button>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </>
//   );
// }

// export default Chatbot;



import React, { useEffect, useState } from "react";
import AdminNavbar from "../../Admin_Panel/Admin_Navbar/Admin_Navbar";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { baseurl } from "../../BaseURL/BaseURL";
import "./ChatBot.css";
import Swal from "sweetalert2";

function Chatbot() {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState(null);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [totalItems, setTotalItems] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Build query parameters for pagination
        const params = new URLSearchParams({
          page: currentPage,
          page_size: itemsPerPage,
        });
        
        if (searchQuery.trim()) {
          params.append('search', searchQuery.trim());
        }
        
        const res = await axios.get(`${baseurl}/responses/?${params.toString()}`);
        
        // Handle different response formats
        let results = [];
        let count = 0;
        
        if (Array.isArray(res.data)) {
          results = res.data;
          count = res.data.length;
        } else if (res.data.results) {
          results = res.data.results || [];
          count = res.data.count || results.length;
        } else {
          results = res.data;
          count = res.data.length || 0;
        }
        
        setData(results);
        setFilteredData(results);
        setTotalItems(count);
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to load data");
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Failed to load chatbot Q&A data',
          confirmButtonColor: '#273c75'
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currentPage, itemsPerPage, searchQuery]);

  /* ================= SEARCH ================= */
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1); // Reset to first page when searching
  };

  const handleCreate = () => {
    navigate("/admin-createq&a");
  };

  const handleEdit = (id) => {
    navigate(`/admin-editqa/${id}`);
  };

  /* ================= DELETE ================= */
  const handleDelete = (id) => {
    Swal.fire({
      title: "Are you sure?",
      text: "This Q&A will be permanently deleted!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#273c75",
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${baseurl}/responses/${id}/`);
          // Refetch data after deletion
          const fetchAfterDelete = async () => {
            try {
              const res = await axios.get(`${baseurl}/responses/?page=${currentPage}&page_size=${itemsPerPage}`);
              let results = [];
              let count = 0;
              
              if (Array.isArray(res.data)) {
                results = res.data;
                count = res.data.length;
              } else if (res.data.results) {
                results = res.data.results || [];
                count = res.data.count || results.length;
              } else {
                results = res.data;
                count = res.data.length || 0;
              }
              
              setData(results);
              setFilteredData(results);
              setTotalItems(count);
            } catch (err) {
              console.error("Error refetching after delete:", err);
            }
          };
          await fetchAfterDelete();
          Swal.fire("Deleted!", "Q&A has been deleted.", "success");
        } catch (err) {
          console.error("Error deleting Q&A:", err);
          Swal.fire("Error!", "Failed to delete Q&A.", "error");
        }
      }
    });
  };

  /* ================= PAGINATION HANDLERS ================= */
  // Calculate pagination values
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage + 1;
  
  // Handle page change
  const handlePageChange = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  // Handle items per page change
  const handleItemsPerPageChange = (e) => {
    const value = parseInt(e.target.value);
    setItemsPerPage(value);
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  // Generate page numbers for pagination
  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      for (let i = 1; i <= totalPages; i++) {
        pageNumbers.push(i);
      }
    } else {
      let startPage = Math.max(1, currentPage - 2);
      let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
      
      if (endPage - startPage + 1 < maxVisiblePages) {
        startPage = Math.max(1, endPage - maxVisiblePages + 1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pageNumbers.push(i);
      }
    }
    
    return pageNumbers;
  };

  return (
    <>
      <AdminNavbar />

      <div className="page-container">
        {/* Header */}
        <div className="page-header">
          <h2>Chatbot Q&A</h2>
        </div>

        {/* Toolbar */}
        <div className="page-toolbar">
          <div className="search-box">
            <input
              type="text"
              placeholder="Search questions or answers..."
              value={searchQuery}
              onChange={handleSearchChange}
            />
            {/* <span className="search-icon">🔍</span> */}
          </div>

          <button
            className="primary-btn"
            style={{
              backgroundColor: "#273c75",
              borderColor: "#273c75",
              color: "white",
            }}
            onClick={handleCreate}
          >
            Create Q&A
          </button>
        </div>

        {/* Table */}
        <div className="table-card">
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ width: '80px' }}>S.No.</th>
                <th style={{ width: '80px' }}>ID</th>
                <th style={{ width: '300px' }}>QUESTION</th>
                <th style={{ width: '400px', maxWidth: '400px' }}>ANSWER</th>
                <th style={{ width: '120px' }}>ACTIONS</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="5" className="no-data">
                    Loading...
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan="5" className="no-data error">
                    {error}
                  </td>
                </tr>
              ) : filteredData.length > 0 ? (
                filteredData.map((item, index) => (
                  <tr key={item.id}>
                    <td>{startIndex + index}</td>
                    <td>{item.id}</td>
                    <td className="question-cell" style={{ 
                      maxWidth: '300px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap'
                    }}>
                      {item.question}
                    </td>
                    <td className="answer-cell" style={{ 
                      maxWidth: '400px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                      paddingRight: '10px'
                    }}>
                      {item.answer}
                    </td>
                    <td className="actions" style={{ 
                      whiteSpace: 'nowrap',
                      padding: '8px'
                    }}>
                      <button
                        className="edit-btn"
                        onClick={() => handleEdit(item.id)}
                        style={{ marginRight: '8px' }}
                      >
                        ✏️
                      </button>
                      <button
                        className="delete-btn"
                        onClick={() => handleDelete(item.id)}
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="no-data">
                    No Q&A data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          {/* Pagination Controls */}
          {totalItems > 0 && (
            <div className="pagination-container" style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '16px',
              borderTop: '1px solid #eee',
              backgroundColor: '#f8f9fa'
            }}>
              {/* Items per page selector */}
              <div className="items-per-page" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '14px', color: '#666' }}>Show:</span>
                <select 
                  value={itemsPerPage} 
                  onChange={handleItemsPerPageChange}
                  style={{
                    padding: '6px 12px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    fontSize: '14px'
                  }}
                >
                  <option value="5">5</option>
                  <option value="10">10</option>
                  <option value="20">20</option>
                  <option value="50">50</option>
                  <option value="100">100</option>
                </select>
                <span style={{ fontSize: '14px', color: '#666' }}>
                  of {totalItems} items
                </span>
              </div>
              
              {/* Page navigation */}
              <div className="pagination-controls" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                {/* First Page */}
                <button
                  onClick={() => handlePageChange(1)}
                  disabled={currentPage === 1}
                  style={{
                    padding: '6px 12px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    background: currentPage === 1 ? '#f8f9fa' : 'white',
                    color: currentPage === 1 ? '#ccc' : '#333',
                    cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                    fontSize: '14px'
                  }}
                >
                  ««
                </button>
                
                {/* Previous Page */}
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  style={{
                    padding: '6px 12px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    background: currentPage === 1 ? '#f8f9fa' : 'white',
                    color: currentPage === 1 ? '#ccc' : '#333',
                    cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                    fontSize: '14px'
                  }}
                >
                  «
                </button>
                
                {/* Page Numbers */}
                {getPageNumbers().map(page => (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    style={{
                      padding: '6px 12px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      background: currentPage === page ? '#273c75' : 'white',
                      color: currentPage === page ? 'white' : '#333',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: currentPage === page ? 'bold' : 'normal'
                    }}
                  >
                    {page}
                  </button>
                ))}
                
                {/* Next Page */}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  style={{
                    padding: '6px 12px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    background: currentPage === totalPages ? '#f8f9fa' : 'white',
                    color: currentPage === totalPages ? '#ccc' : '#333',
                    cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                    fontSize: '14px'
                  }}
                >
                  »
                </button>
                
                {/* Last Page */}
                <button
                  onClick={() => handlePageChange(totalPages)}
                  disabled={currentPage === totalPages}
                  style={{
                    padding: '6px 12px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    background: currentPage === totalPages ? '#f8f9fa' : 'white',
                    color: currentPage === totalPages ? '#ccc' : '#333',
                    cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                    fontSize: '14px'
                  }}
                >
                  »»
                </button>
              </div>
              
              {/* Current page info */}
              <div className="page-info" style={{ fontSize: '14px', color: '#666' }}>
                Page {currentPage} of {totalPages}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Chatbot;